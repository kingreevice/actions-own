<!-- Thanks for your interest in cheerio!

Please note that issues should be primarily used for tracking bugs and feature requests.
If you have a more general question, please consider consulting StackOverflow first:
https://stackoverflow.com/questions/tagged/cheerio

If you think you uncovered a bug, please try to provide a minimal example that triggers the behavior.
Please note that we will not investigate issues that perform HTTP requests, as the source might already have changed.
-->
